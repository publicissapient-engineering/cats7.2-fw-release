package com.publicissapient.anoroc.model;

import lombok.Data;

@Data
public class ScreenShot {

    private String mimeType;

    private String data;

    private String name;

}
