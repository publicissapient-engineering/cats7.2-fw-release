#!/usr/bin/env bash

build_project()
{
  cd $1
  echo "###### BUILDING $1 #######"
  mvn clean install
  install_jar $1
  cd ..
}

install_jar()
{
  project = $1
  mvn org.apache.maven.plugins:maven-install-plugin:2.5.2:install-file -Dfile=./target/$1-1.0.jar
}

# build anoroc-core
build_project anoroc-core
build_project anoroc-parser
build_project anoroc-selenium-executor
build_project anoroc-reporting

build_project anoroc-parser-spring-boot-autoconfigure
build_project anoroc-selenium-executor-spring-boot-autoconfigure
build_project anoroc-reporting-spring-boot-autoconfigure

build_project anoroc-parser-spring-boot-starter
build_project anoroc-selenium-executor-spring-boot-starter
build_project anoroc-reporting-spring-boot-starter

build_project anoroc-cli

build_project anoroc-api
