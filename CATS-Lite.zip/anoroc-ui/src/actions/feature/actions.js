export const ADD_FEATURE = "ADD_FEATURE";

export const addFeature = feature => ({
  type: ADD_FEATURE,
  payload: { feature }
});

export const LIST_FEATURE = "LIST_FEATURE";

export const listFeature = features => ({
  type: LIST_FEATURE,
  payload: { features }
});

export const FEATURE_COUNT = "FEATURE_COUNT";

export const getFeatureCount = count => ({
  type: FEATURE_COUNT,
  payload: { count }
});

export const SET_FEATURE_PAGE = "SET_FEATURE_PAGE";

export const setFeaturePage = page => ({
  type: SET_FEATURE_PAGE,
  payload: { page }
});

export const SET_FEATURE_SIZE = "SET_FEATURE_SIZE";

export const setFeatureSize = size => ({
  type: SET_FEATURE_SIZE,
  payload: { size }
});

export const UPDATE_FEATURE = "UPDATE_FEATURE";

export const updateFeature = feature => ({
  type: UPDATE_FEATURE,
  payload: { feature }
});

export const SET_SELECTED_FEATURE = "SET_SELECTED_FEATURE";

export const setSelectedFeature = selectedFeature => ({
  type: SET_SELECTED_FEATURE,
  payload: { selectedFeature }
});
