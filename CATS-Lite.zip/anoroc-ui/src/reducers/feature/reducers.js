import {
  ADD_FEATURE,
  LIST_FEATURE,
  FEATURE_COUNT,
  SET_FEATURE_PAGE,
  SET_FEATURE_SIZE,
  UPDATE_FEATURE,
  SET_SELECTED_FEATURE
} from "../../actions/feature/actions";

export const features = (state = [], action) => {
  const { type, payload } = action;
  switch (type) {
    case ADD_FEATURE: {
      return state;
    }
    case LIST_FEATURE: {
      const { features } = payload;
      const featuresList = {
        ...state,
        data: features
      };
      return featuresList;
    }
    case FEATURE_COUNT: {
      const { count } = payload;
      const featureCount = {
        ...state,
        count
      };
      return featureCount;
    }
    case SET_FEATURE_PAGE: {
      const { page } = payload;
      const pageData = {
        ...state,
        page
      };
      return pageData;
    }
    case SET_FEATURE_SIZE: {
      const { size } = payload;
      const sizeData = {
        ...state,
        size
      };
      return sizeData;
    }
    case UPDATE_FEATURE: {
      const { feature: updatedFeature } = payload;
      return {
        ...state,
        data: state.data.map(feature => {
          if (feature.id === updatedFeature.id) {
            return updatedFeature;
          }
          return feature;
        })
      };
    }
    case SET_SELECTED_FEATURE: {
      const { selectedFeature } = payload;
      const selectedFeatureData = {
        ...state,
        selectedFeature
      };
      return selectedFeatureData;
    }
    default:
      return state;
  }
};
