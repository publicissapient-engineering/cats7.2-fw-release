import { BASE_URL } from "../../EnvVariables";
import {
  addFeature,
  listFeature,
  getFeatureCount,
  setFeaturePage,
  setFeatureSize,
  updateFeature,
  setSelectedFeature
} from "../../actions/feature/actions";
import {
  startLoading,
  stopLoading,
  displayMessage
} from "../../actions/common/actions";

export const addFeatureRequest = (
  name,
  featureType = "KARATE",
  applicationId = 0,
  content = "",
  xpath = ""
) => async dispatch => {
  try {
    dispatch(startLoading());
    const body = {
      name: name,
      content: content,
      xpath: xpath,
      featureType: featureType,
      applicationId: applicationId
    };
    const response = await fetch(`${BASE_URL}/api/feature/save`, {
      headers: {
        "Content-Type": "application/json"
      },
      method: "post",
      body: JSON.stringify(body)
    });
    const feature = await response.json();
    if (response.status === 200) {
      dispatch(addFeature(feature));
      dispatch(listFeatureRequest());
      dispatch(displayMessage("Feature added successfully."));
    } else {
      dispatch(
        displayMessage("Could not add the feature. Try the operation again.")
      );
    }
    dispatch(stopLoading());
  } catch (e) {
    dispatch(
      displayMessage("Could not add the feature. Try the operation again")
    );
    dispatch(stopLoading());
  }
};

export const getFeatureCountRequest = () => async dispatch => {
  dispatch(startLoading());
  console.log("Get feature count request");
  try {
    const featureCountResponse = await fetch(`${BASE_URL}/api/feature/count`, {
      headers: {
        "Content-Type": "application/json"
      },
      method: "get"
    });
    const featureCount = await featureCountResponse.json();
    dispatch(getFeatureCount(featureCount.count));
    dispatch(stopLoading());
  } catch (e) {
    dispatch(
      displayMessage("Could not fetch feature count. Try the operation again")
    );
    dispatch(stopLoading());
  }
};

export const listFeatureRequest = (page = 0, size = 10) => async dispatch => {
  try {
    dispatch(startLoading());
    const featureCountResponse = await fetch(`${BASE_URL}/api/feature/count`);
    const featureCount = await featureCountResponse.json();
    dispatch(getFeatureCount(featureCount.count));
    dispatch(setFeaturePage(page));
    dispatch(setFeatureSize(size));
    const response = await fetch(
      `${BASE_URL}/api/feature/list?page=${page}&size=${size}`
    );
    const features = await response.json();
    dispatch(listFeature(features));
    if (features.length > 0) {
      dispatch(setSelectedFeature(features[0]));
    }
    dispatch(stopLoading());
  } catch (e) {
    dispatch(
      displayMessage("Could not fetch the features. Try the operation again")
    );
    dispatch(stopLoading());
  }
};

export const updateFeatureRequest = (
  id = 0,
  name = "",
  content = "",
  xpath = "",
  featureType = "KARATE",
  applicationId = 0
) => async dispatch => {
  try {
    const body = {
      id: id,
      name: name,
      content: content,
      xpath: xpath,
      featureType: featureType,
      applicationId: applicationId
    };
    const response = await fetch(`${BASE_URL}/api/feature/save`, {
      headers: {
        "Content-Type": "application/json"
      },
      method: "post",
      body: JSON.stringify(body)
    });
    const feature = await response.json();
    if (response.status === 200) {
      dispatch(displayMessage("Feature updated successfully."));
      dispatch(updateFeature(feature));
      dispatch(setSelectedFeature(feature));
    } else {
      dispatch(
        displayMessage("Could not update the feature. Try the operation again.")
      );
    }
    dispatch(stopLoading());
  } catch (e) {
    dispatch(
      displayMessage("Could not update the feature. Try the operation again")
    );
    dispatch(stopLoading());
  }
};

export const setSelectedFeatureRequest = feature => async dispatch => {
  dispatch(setSelectedFeature(feature));
};
