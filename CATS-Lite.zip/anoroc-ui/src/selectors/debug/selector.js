export const getSessionId = state => {
  return state.debug.sessionId;
};
