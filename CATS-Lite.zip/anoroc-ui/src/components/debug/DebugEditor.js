const DebugEditor = () => {
  return "";
};

export default DebugEditor;
