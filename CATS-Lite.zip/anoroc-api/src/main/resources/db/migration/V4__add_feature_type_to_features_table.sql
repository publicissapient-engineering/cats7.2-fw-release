ALTER TABLE features ADD COLUMN feature_Type VARCHAR (10) not null default 'ANOROC';
