ALTER TABLE Environment ADD COLUMN karate_content CLOB(64 K)  default null;
ALTER TABLE Environment ADD COLUMN anoroc_content CLOB(64 K)  default null;