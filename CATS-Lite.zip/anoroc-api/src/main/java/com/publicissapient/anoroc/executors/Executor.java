package com.publicissapient.anoroc.executors;

import com.publicissapient.anoroc.messaging.payload.RunPayload;

public interface Executor {

    void run(RunPayload run);

}
