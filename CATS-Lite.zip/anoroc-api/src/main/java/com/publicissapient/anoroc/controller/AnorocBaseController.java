package com.publicissapient.anoroc.controller;

import com.publicissapient.anoroc.payload.request.BusinessScenarioRequest;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;

public class AnorocBaseController {

    protected PageRequest pageRequestBuilder(Integer page, Integer size) {
        return PageRequest.of(page, size, Sort.by("createdAt").descending());
    }

    public HttpStatus getStatusCode(long id) {
        return (id == 0l) ? HttpStatus.CREATED : HttpStatus.ACCEPTED;
    }
}
