package com.publicissapient.anoroc.payload.request;

import com.publicissapient.anoroc.model.FeatureType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
final public class FeatureRequest {

    private Long id;

    @NotBlank
    @Size(min =3,max = 512)
    private String name;

    @NotNull
    private String content;

    @NotNull
    private String xPath;

    @NotNull
    private FeatureType featureType ;

    private long applicationId;

}
