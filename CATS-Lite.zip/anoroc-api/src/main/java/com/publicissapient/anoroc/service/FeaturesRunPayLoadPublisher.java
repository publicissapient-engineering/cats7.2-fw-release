package com.publicissapient.anoroc.service;

import com.publicissapient.anoroc.messaging.sender.MessageSender;
import com.publicissapient.anoroc.model.*;
import com.publicissapient.anoroc.repository.RunRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Arrays;

@Service
public class FeaturesRunPayLoadPublisher extends  AnorocService implements PayLoadPublisher {

    @Autowired
    private RunRepository runRepository;

    @Autowired
    private FeatureService featureService;

    @Autowired
    private EnvironmentService environmentService;

    @Autowired
    private MessageSender sender;

    @Override
    public boolean isRunTypeMatches(RunType runType) {
        return runType.equals(RunType.FEATURE);
    }

    @Override
    public Run saveAndPublishToQueue(Long featureId, long environmentId) throws Exception {
        FeatureEntity featureEntity = featureService.featureById(featureId);
        Environment environment = environmentService.getEnv(environmentId);
        Run run = save(featureEntity, environment);
        sender.sendToRunInitQueue(buildMessage(featureEntity, run));
        return run;
    }

    private Run save(FeatureEntity featureEntity, Environment environment) {
        return runRepository.save(createRun(featureEntity, environment));
    }

    private Run createRun(FeatureEntity featureEntity, Environment environment) {
        return Run.builder().details(featureEntity.getName())
                .status(RunStatus.RUNNING)
                .runType(RunType.FEATURE)
                .features(Arrays.asList(featureEntity))
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .environment(environment)
                .build();
    }
}
