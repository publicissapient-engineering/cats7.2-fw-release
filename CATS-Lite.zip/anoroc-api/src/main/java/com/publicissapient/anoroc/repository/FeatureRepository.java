package com.publicissapient.anoroc.repository;

import com.publicissapient.anoroc.model.FeatureEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FeatureRepository extends JpaRepository<FeatureEntity,Long> {

    List<FeatureEntity> findByApplicationId(long applicationId);

    long countByApplicationId(long applicationId);

    List<FeatureEntity> findByBusinessScenariosId(long businessScenarioId);
}
