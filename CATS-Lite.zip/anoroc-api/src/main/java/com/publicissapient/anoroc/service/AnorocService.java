package com.publicissapient.anoroc.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.publicissapient.anoroc.exception.*;
import com.publicissapient.anoroc.messaging.payload.BusinessScenarioRunPayload;
import com.publicissapient.anoroc.messaging.payload.RunPayload;
import com.publicissapient.anoroc.model.FeatureEntity;
import com.publicissapient.anoroc.model.FeatureType;
import com.publicissapient.anoroc.model.Run;
import com.publicissapient.anoroc.model.RunStatus;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;


@Slf4j
public class AnorocService {

    protected PageRequest pageRequestBuilder(Integer page, Integer size) {
        return PageRequest.of(page, size, Sort.by("createdAt").descending());
    }

    protected RunPayload buildMessage(FeatureEntity featureEntity, Run run) throws Exception{
        return RunPayload.builder()
                .name(featureEntity.getName())
                .featureId(featureEntity.getId())
                .featureType(featureEntity.getFeatureType())
                .runId(run.getId())
                .content(featureEntity.getContent())
                .status(RunStatus.RUNNING)
                .environment(run.getEnvironment().getName())
                .args(getArgs(run, featureEntity))
                .xpath(featureEntity.getXPath()).build();
    }

    protected BusinessScenarioRunPayload createBusinessScenarioRunPayLoad(long businessScenarioId, long runId, long envId) {
        return BusinessScenarioRunPayload.builder()
                .runId(runId)
                .environmentId(envId)
                .businessScenarioId(businessScenarioId)
                .build();
    }

    protected Map<String, Object> getArgs(Run run, FeatureEntity featureEntity) throws Exception {
        Map<String, Object> xpathMap = new HashMap<>();
        if(featureEntity.getFeatureType() == FeatureType.ANOROC) {
            xpathMap.putAll(getJsonMap(run.getEnvironment().getAnorocContent()));
        } else {
            xpathMap.putAll(getJsonMap(run.getEnvironment().getKarateContent()));
            xpathMap.putAll(getJsonMap(featureEntity.getXPath()));
        }
        return xpathMap;
    }

    protected BusinessScenarioNotFoundException getBusinessScenarioNotFoundException(long id) {
        return new BusinessScenarioNotFoundException("Business Scenario not found for an id : "+id);
    }

    protected EnvironmentNotFoundException getEnvironmentNotFoundException(long id) {
        return new EnvironmentNotFoundException("Environment not found for an id : "+id);
    }

    protected BusinessScenarioRunFeaturesNotFoundException getBusinessScenarioRunFeaturesNotFoundException(long businessScenarioRunId){
        return new BusinessScenarioRunFeaturesNotFoundException("BusinessScenarioRunFeatures not found for an business scenario run id"+businessScenarioRunId);
    }

    protected BusinessScenarioRunNotFoundException getBusinessScenarioRunFoundException(long businessScenarioRunId){
        return new BusinessScenarioRunNotFoundException("BusinessScenarioRun not found for an business scenario run id"+businessScenarioRunId);
    }

    protected RunNotFoundException getRunNotFoundException(long id) {
        return new RunNotFoundException("Run features not found for an id : "+id);
    }

    protected Map<String, Object> getJsonMap(String jsonString) throws Exception {
        return StringUtils.isEmpty(jsonString) ? Collections.emptyMap() : new ObjectMapper().readValue(jsonString, Map.class);
    }


}
