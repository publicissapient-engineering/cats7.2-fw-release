package com.publicissapient.anoroc.exception;

public class RunNotFoundException extends RuntimeException {


    public RunNotFoundException(String msg) {
        super(msg);
    }
}
