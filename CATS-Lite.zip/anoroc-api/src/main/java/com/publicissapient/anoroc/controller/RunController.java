package com.publicissapient.anoroc.controller;

import com.publicissapient.anoroc.exception.RunNotFoundException;
import com.publicissapient.anoroc.exception.RunTypeNotMatchException;
import com.publicissapient.anoroc.model.RunType;
import com.publicissapient.anoroc.payload.mapper.RunModelMapper;
import com.publicissapient.anoroc.payload.request.BusinessScenarioRunRequest;
import com.publicissapient.anoroc.payload.request.FeatureRunRequest;
import com.publicissapient.anoroc.payload.request.PaginationRequest;
import com.publicissapient.anoroc.payload.response.RunCount;
import com.publicissapient.anoroc.payload.response.RunDetail;
import com.publicissapient.anoroc.service.RunService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@Slf4j
@RequestMapping("/run")
public class RunController {

    @Autowired
    private RunService runService;

    @Autowired
    private RunModelMapper runModelMapper;

    @GetMapping("/count")
    public RunCount getCount() {
        return new RunCount(runService.getCount());
    }

    @GetMapping("/list")
    public List<RunDetail> runs(@Valid PaginationRequest pagination) {
        return runModelMapper.runs(runService.runs(pagination.getPage(), pagination.getSize()));
    }

    @PostMapping("/feature")
    @ResponseStatus(HttpStatus.ACCEPTED)
    public ResponseEntity<RunDetail> runFeature(@Valid @RequestBody FeatureRunRequest runRequest) throws Exception, RunTypeNotMatchException {
        return new ResponseEntity<RunDetail>(runModelMapper.runDetails(runService.run(runRequest.getFeatureId(), runRequest.getEnvironmentId(), RunType.FEATURE)), HttpStatus.ACCEPTED);
    }

    @PostMapping("/businessScenario")
    @ResponseStatus(HttpStatus.ACCEPTED)
    public ResponseEntity<RunDetail> runBusinessScenario(@Valid @RequestBody BusinessScenarioRunRequest runRequest) throws Exception, RunTypeNotMatchException {
       return new ResponseEntity<RunDetail>(runModelMapper.runDetails(runService.run(runRequest.getBusinessScenarioId(), runRequest.getEnvironmentId(), RunType.BUSINESS_SCENARIO)), HttpStatus.ACCEPTED);
    }

    @ExceptionHandler(value = {RunNotFoundException.class, RunTypeNotMatchException.class})
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public void RunAndRunTypeMatchNotFound() {
    }

    @ExceptionHandler(value = {Exception.class})
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public void internalServerError() {
    }

}
