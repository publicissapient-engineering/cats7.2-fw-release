package com.publicissapient.anoroc.service;

import com.publicissapient.anoroc.exception.FeatureNotFoundException;
import com.publicissapient.anoroc.model.Application;
import com.publicissapient.anoroc.model.FeatureEntity;
import com.publicissapient.anoroc.repository.ApplicationRepository;
import com.publicissapient.anoroc.repository.FeatureRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FeatureService {

    @Autowired
    private FeatureRepository featureRepository;

    @Autowired
    private ApplicationRepository applicationRepository;

    public long count() {
        return featureRepository.count();
    }

    public List<FeatureEntity> featureList(Integer page, Integer size) {
        return featureRepository.findAll(pageRequestBuilder(page, size)).getContent();
    }

    private PageRequest pageRequestBuilder(Integer page, Integer size) {
        return PageRequest.of(page, size, Sort.by("createdAt").descending());
    }

    public FeatureEntity featureById(Long featureId) throws FeatureNotFoundException {
        return featureRepository.findById(featureId)
                .orElseThrow(() -> new FeatureNotFoundException("Feature Not Found"));
    }

    public FeatureEntity save(FeatureEntity featureEntity, long applicationId) {
        Application application = applicationRepository.findById(applicationId).get();
        featureEntity.setApplication(application);
        return save(featureEntity);
    }

    public FeatureEntity save(FeatureEntity featureEntity) {
        return featureRepository.save(featureEntity);
    }

    public List<FeatureEntity> getFeatures(long applicationId) {
       return featureRepository.findByApplicationId(applicationId);
    }

    public List<FeatureEntity> getFeaturesByBusinessScenarioId(long businessScenarioId) {
        return featureRepository.findByBusinessScenariosId(businessScenarioId);
    }

    public long getFeaturescount(long applicationId) {
        return featureRepository.countByApplicationId(applicationId);
    }
}
