package com.publicissapient.anoroc.executors.reports;

import lombok.extern.slf4j.Slf4j;
import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;
import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileVisitOption;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;

@Component
@Slf4j
public class ReportGenerator {

    public static final String REPORT_STATIC_PATH = "static/";

    public String initiateHtmlReportGeneration(Long runId, String projectName) {
        Configuration config = new Configuration(new File(this.getClass().getClassLoader().getResource(REPORT_STATIC_PATH).getPath() + runId), projectName);
        ReportBuilder reportBuilder = new ReportBuilder(getJsonFiles(runId), config);
        reportBuilder.generateReports();
        return runId + com.publicissapient.anoroc.generator.HtmlReportGenerator.HTML_REPORT_FILE_PATH;
    }

    private List<String> getJsonFiles(Long runId) {
        Collection<File> jsonFiles = FileUtils.listFiles(new File(this.getClass().getClassLoader().getResource(REPORT_STATIC_PATH).getPath() + runId), new String[]{"json"}, true);
        List<String> jsonPaths = new ArrayList(jsonFiles.size());
        jsonFiles.forEach(fileObj -> jsonPaths.add(fileObj.getAbsolutePath()));
        return jsonPaths;
    }

    public void cleanReportDir(Long runId) {
        try {
            Path rootPath = Paths.get(this.getClass().getClassLoader().getResource(REPORT_STATIC_PATH).getPath() + runId);
            if (Files.exists(rootPath)) {
                Files.walk(rootPath, FileVisitOption.FOLLOW_LINKS)
                        .sorted(Comparator.reverseOrder())
                        .map(Path::toFile)
                        .peek(System.out::println)
                        .forEach(File::delete);
            }
        } catch (IOException e) {
            log.error(e.getMessage(), e);
        }

    }
}
