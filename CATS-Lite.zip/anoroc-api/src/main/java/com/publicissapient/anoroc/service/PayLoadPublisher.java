package com.publicissapient.anoroc.service;

import com.publicissapient.anoroc.model.Environment;
import com.publicissapient.anoroc.model.Run;
import com.publicissapient.anoroc.model.RunType;

import java.io.IOException;

public interface PayLoadPublisher {

    public Run saveAndPublishToQueue(Long id, long envId) throws Exception;

    public boolean isRunTypeMatches(RunType runType);
}
