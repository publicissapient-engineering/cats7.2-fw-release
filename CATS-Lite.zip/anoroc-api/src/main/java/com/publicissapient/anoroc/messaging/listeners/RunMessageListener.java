package com.publicissapient.anoroc.messaging.listeners;

import com.publicissapient.anoroc.executors.factory.ExecutorFactory;
import com.publicissapient.anoroc.executors.reports.ReportGenerator;
import com.publicissapient.anoroc.messaging.payload.RunPayload;
import com.publicissapient.anoroc.messaging.sender.MessageSender;
import com.publicissapient.anoroc.model.RunStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
@Slf4j
public class RunMessageListener {

    @Autowired
    private ExecutorFactory executorFactory;

    @Autowired
    private MessageSender messageSender;

    @Autowired
    private ReportGenerator reportGenerator;


    @JmsListener(destination = "${anoroc.activemq.run.init.queue}", containerFactory = "jsaFactory")
    public void process(RunPayload payload) throws IOException {
        log.debug("Received run payload "+payload.getName() + " for engine "+payload.getFeatureType());
        reportGenerator.cleanReportDir(payload.getRunId());
        executorFactory.getExecutor(payload.getFeatureType()).run(payload);
        if(payload.getStatus()!= RunStatus.ERROR){
            payload.setReportPath(reportGenerator.initiateHtmlReportGeneration(payload.getRunId(),payload.getName()));
        }
        messageSender.sendToRunUpdateQueue(payload);
    }

}
