package com.publicissapient.anoroc.service;

import com.publicissapient.anoroc.executors.factory.ExecutorFactory;
import com.publicissapient.anoroc.executors.reports.ReportGenerator;
import com.publicissapient.anoroc.messaging.payload.BusinessScenarioRunPayload;
import com.publicissapient.anoroc.messaging.payload.RunPayload;
import com.publicissapient.anoroc.messaging.sender.MessageSender;
import com.publicissapient.anoroc.model.BusinessScenario;
import com.publicissapient.anoroc.model.FeatureEntity;
import com.publicissapient.anoroc.model.Run;
import com.publicissapient.anoroc.model.RunStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class BusinessScenarioRunService extends AnorocService {

    @Autowired
    private RunService runService;

    @Autowired
    private BusinessScenarioService businessScenarioService;

    @Autowired
    private ExecutorFactory executorFactory;

    @Autowired
    private MessageSender sender;

    @Autowired
    private ReportGenerator reportGenerator;

    @Transactional
    public BusinessScenarioRunPayload run(BusinessScenarioRunPayload businessScenarioRunPayload) {

        BusinessScenario businessScenario = businessScenarioService.getBusinessScenario(businessScenarioRunPayload.getBusinessScenarioId());
        Run run  = runService.getById(businessScenarioRunPayload.getRunId());
        cleanReportDirectory(businessScenarioRunPayload.getRunId());
        List<RunPayload> featureRunPayloads = businessScenario.getFeatures().stream()
                                            .map(feature -> executeFeature(feature, businessScenarioRunPayload, businessScenario, run))
                                           .collect(Collectors.toList());
        generateReport(businessScenarioRunPayload, businessScenario);
        updateBusinessScenarioRunPayload(businessScenarioRunPayload, featureRunPayloads);
        sender.sendToBusinessScenarioRunUpdateQueue(businessScenarioRunPayload);
        return businessScenarioRunPayload;
    }

    private RunPayload executeFeature(FeatureEntity entity,  BusinessScenarioRunPayload businessScenarioRunPayload, BusinessScenario businessScenario, Run run) {
        RunPayload featureRunPayload = null;
        try {
            featureRunPayload = buildMessage(entity, run);
            executorFactory.getExecutor(entity.getFeatureType()).run(featureRunPayload);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            featureRunPayload = RunPayload.builder().status(RunStatus.FAILURE).build();
        }
        return featureRunPayload;
    }

    private void generateReport(BusinessScenarioRunPayload businessScenarioRunPayload, BusinessScenario businessScenario) {
        String reportUrl = reportGenerator.initiateHtmlReportGeneration(businessScenarioRunPayload.getRunId(),businessScenario.getName());
        businessScenarioRunPayload.setReportUrl(reportUrl);
    }

    private void updateBusinessScenarioRunPayload(BusinessScenarioRunPayload businessScenarioRunPayload, List<RunPayload> featureRunPayloads) {
        boolean isAnyFeatureHasFailedStatus = featureRunPayloads.stream().filter(featureRunPayload -> featureRunPayload.getStatus().equals(RunStatus.FAILURE)).findAny().isPresent();
        businessScenarioRunPayload.setAnyFeatureHasFailedStatus(isAnyFeatureHasFailedStatus);
        businessScenarioRunPayload.setStatus(isAnyFeatureHasFailedStatus ? RunStatus.FAILURE : RunStatus.SUCCESS);
    }

    public void updateRun(BusinessScenarioRunPayload businessScenarioRunPayload) {
        Run run  = runService.getById(businessScenarioRunPayload.getRunId());
        runService.updateRun(businessScenarioRunPayload, run);
    }

    private void cleanReportDirectory(Long runId) {
        reportGenerator.cleanReportDir(runId);
    }

}
