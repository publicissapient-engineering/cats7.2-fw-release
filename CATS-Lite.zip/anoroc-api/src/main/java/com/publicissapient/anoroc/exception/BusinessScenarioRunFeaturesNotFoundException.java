package com.publicissapient.anoroc.exception;

public class BusinessScenarioRunFeaturesNotFoundException extends RuntimeException {

    public BusinessScenarioRunFeaturesNotFoundException(String message) {
        super(message);
    }
}
