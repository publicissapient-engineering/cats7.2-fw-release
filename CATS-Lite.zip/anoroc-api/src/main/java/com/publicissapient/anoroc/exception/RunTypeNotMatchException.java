package com.publicissapient.anoroc.exception;

public class RunTypeNotMatchException extends Throwable {

    public RunTypeNotMatchException(String msg) {
        super(msg);
    }
}
