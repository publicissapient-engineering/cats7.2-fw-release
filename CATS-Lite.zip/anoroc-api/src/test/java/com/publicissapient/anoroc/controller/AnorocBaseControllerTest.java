package com.publicissapient.anoroc.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class AnorocBaseControllerTest {

    protected String asJsonRequestBody(Object requestObject) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.writeValueAsString(requestObject);
    }
}
