package com.publicissapient.anoroc.karate;

import com.publicissapient.anoroc.executors.karate.KarateExecutor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.NONE;

@SpringBootTest(webEnvironment = NONE)
@ActiveProfiles("test")
public class KarateExecutorTest {

    @Autowired
    KarateExecutor executor;

}
