insert into batch (id, name, description, created_at, updated_at, application_id) values(1, 'Batch smoke test', 'Batch smoke test description',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP, 1);
insert into batch (id, name, description, created_at, updated_at, application_id) values(2, 'Batch smoke test 2', 'Batch smoke test description 2',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP, 1);
