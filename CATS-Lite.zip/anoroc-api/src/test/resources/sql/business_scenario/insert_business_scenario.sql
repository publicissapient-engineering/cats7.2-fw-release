insert into business_scenario (id, name, description, created_at, updated_at) values(1, 'smoke_test', 'smoke_test_desc',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP);
