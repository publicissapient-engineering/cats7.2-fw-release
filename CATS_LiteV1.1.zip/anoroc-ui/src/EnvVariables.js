export const BASE_URL = process.env.REACT_APP_API_URL;
export const RP_LAUNCH_URL = process.env.REACT_APP_RP_LAUNCH_URL;