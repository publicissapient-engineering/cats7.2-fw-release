import React from "react";
import Header from "./components/menu/Header";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import Application from "./components/application/Application";
import Feature from "./components/feature/Feature";
import Debug from "./components/debug/Debug";
import Run from "./components/runs/Run";
import BusinessScenario from "./components/businessScenario/BusinessScenario";
import Environment from "./components/environment/Environment";
import Grid from "@material-ui/core/Grid";
import Box from "@material-ui/core/Box";
import Loading from "./components/common/Loading";
import AlertMessage from "./components/common/AlertMessage";
import GlobalObject from "./components/globalObject/GlobalObject";
import Reports from "./components/reports/Reportportal"

const Anoroc = () => {
  return (
    <Grid item xs={12}>
      <Box>
        <Header />
        <Loading />
        <AlertMessage />
        <BrowserRouter>
          <Switch>
            <Route exact path="/" component={Feature} />
            <Route exact path="/applications" component={Application} />
            <Route exact path="/features" component={Feature} />
            <Route exact path="/debug" component={Debug} />
            <Route exact path="/runs" component={Run} />
            <Route exact path="/globalObjects" component={GlobalObject} />
            <Route exact path="/environments" component={Environment} />
            <Route
              exact
              path="/business-scenario"
              component={BusinessScenario}
            />
             <Route exact path="/reports" component={Reports} />
          </Switch>
        </BrowserRouter>
      </Box>
    </Grid>
  );
};

export default Anoroc;
