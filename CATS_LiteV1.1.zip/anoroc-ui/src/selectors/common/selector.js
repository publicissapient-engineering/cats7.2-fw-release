export const loading = state => {
  return state.loading;
};

export const getMessage = state => {
  return state.message;
};
