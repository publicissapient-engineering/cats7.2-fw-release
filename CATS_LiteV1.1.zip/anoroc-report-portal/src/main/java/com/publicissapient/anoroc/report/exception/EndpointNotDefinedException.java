package com.publicissapient.anoroc.report.exception;

public class EndpointNotDefinedException  extends Exception{

    public EndpointNotDefinedException(String message) {
        super(message);
    }
}
