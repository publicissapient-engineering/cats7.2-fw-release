package com.publicissapient.anoroc.report.exception;

public class ApiKeyNotDefinedException extends Exception{

    public ApiKeyNotDefinedException(String message) {
        super(message);
    }
}
