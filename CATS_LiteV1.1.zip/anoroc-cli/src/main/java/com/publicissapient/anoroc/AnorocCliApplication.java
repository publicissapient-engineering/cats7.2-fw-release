package com.publicissapient.anoroc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnorocCliApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnorocCliApplication.class, args);
	}

}
