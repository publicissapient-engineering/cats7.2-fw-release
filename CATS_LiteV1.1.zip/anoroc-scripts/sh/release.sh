#!/usr/bin/env bash

mkdir anoroc-dist
cp anoroc-cli/target/anoroc-cli-1.0.jar anoroc-dist
cd anoroc-dist
mv anoroc-cli-1.0.jar anoroc
mkdir features
mkdir reports
cd ..
tar -zcvf anoroc-dist.tar.gz anoroc-dist
tar -tf anoroc-dist.tar.gz
