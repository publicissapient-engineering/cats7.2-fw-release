#!/usr/bin/env bash

git clone https://del.tools.publicis.sapient.com/bitbucket/scm/anor/anoroc-core.git
git clone https://del.tools.publicis.sapient.com/bitbucket/scm/anor/anoroc-parser.git
git clone https://del.tools.publicis.sapient.com/bitbucket/scm/anor/anoroc-selenium-executor.git
git clone https://del.tools.publicis.sapient.com/bitbucket/scm/anor/anoroc-reporting.git

git clone https://del.tools.publicis.sapient.com/bitbucket/scm/anor/anoroc-parser-spring-boot-autoconfigure.git
git clone https://del.tools.publicis.sapient.com/bitbucket/scm/anor/anoroc-selenium-executor-spring-boot-autoconfigure.git
git clone https://del.tools.publicis.sapient.com/bitbucket/scm/anor/anoroc-reporting-spring-boot-autoconfigure.git

git clone https://del.tools.publicis.sapient.com/bitbucket/scm/anor/anoroc-parser-spring-boot-starter.git
git clone https://del.tools.publicis.sapient.com/bitbucket/scm/anor/anoroc-selenium-executor-spring-boot-starter.git
git clone https://del.tools.publicis.sapient.com/bitbucket/scm/anor/anoroc-reporting-spring-boot-starter.git

git clone https://del.tools.publicis.sapient.com/bitbucket/scm/anor/anoroc-cli.git

git clone https://del.tools.publicis.sapient.com/bitbucket/scm/anor/anoroc-scripts.git
git clone https://del.tools.publicis.sapient.com/bitbucket/scm/anor/anoroc-api.git
git clone https://del.tools.publicis.sapient.com/bitbucket/scm/anor/anoroc-ui.git