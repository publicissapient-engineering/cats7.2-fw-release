package com.publicissapient.anoroc.exception;

public class FeatureFileNotFoundException extends RuntimeException {

    public FeatureFileNotFoundException(Exception e) {
        super(e);
    }
}
