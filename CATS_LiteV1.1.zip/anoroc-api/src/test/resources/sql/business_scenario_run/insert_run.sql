INSERT INTO RUNS (id,details,report_url,run_type,status,created_at,updated_at,environment_id) VALUES (1,'Sample Run 1','/reports/123456',1,0,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,1);
