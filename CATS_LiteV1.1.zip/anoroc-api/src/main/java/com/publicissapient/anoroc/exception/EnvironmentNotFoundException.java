package com.publicissapient.anoroc.exception;

public class EnvironmentNotFoundException extends  RuntimeException {

    public EnvironmentNotFoundException(String message) {
        super(message);
    }
}
