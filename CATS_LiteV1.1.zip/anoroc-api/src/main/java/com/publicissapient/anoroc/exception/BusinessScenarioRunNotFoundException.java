package com.publicissapient.anoroc.exception;

public class BusinessScenarioRunNotFoundException extends  RuntimeException{

    public BusinessScenarioRunNotFoundException(String msg) {
        super(msg);
    }
}
