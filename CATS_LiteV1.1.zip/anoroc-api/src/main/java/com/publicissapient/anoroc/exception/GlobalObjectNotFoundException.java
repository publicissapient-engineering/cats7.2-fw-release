package com.publicissapient.anoroc.exception;

public class GlobalObjectNotFoundException extends  RuntimeException{

    public GlobalObjectNotFoundException(String msg){
        super(msg);
    }
}
