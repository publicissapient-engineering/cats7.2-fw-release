package com.publicissapient.anoroc.exception;

public class RunTypeNotFoundException extends Throwable {

    public RunTypeNotFoundException(String msg) {
        super(msg);
    }
}
