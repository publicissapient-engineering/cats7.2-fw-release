package com.publicissapient.anoroc.exception;

public class BatchNotFoundException extends  RuntimeException {

    public BatchNotFoundException(String msg) {
        super(msg);
    }
}
