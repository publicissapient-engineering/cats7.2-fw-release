package com.publicissapient.anoroc.exception;

public class WebDriverInitializationException extends  RuntimeException {

    public WebDriverInitializationException(String message) {
        super(message);
    }
}
