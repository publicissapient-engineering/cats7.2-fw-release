package com.publicissapient.anoroc.payload.request;

public class ScenarioOutlineRequest {

    private Long id;

    private String name;

    private Long featureId;

}
