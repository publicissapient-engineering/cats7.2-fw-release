package com.publicissapient.anoroc.exception;

public class BusinessScenarioNotFoundException extends  RuntimeException{

    public BusinessScenarioNotFoundException(String msg) {
        super(msg);
    }
}
