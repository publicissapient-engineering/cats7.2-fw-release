package com.publicissapient.anoroc.exception;

public class FeatureNotFoundException extends RuntimeException {

    public FeatureNotFoundException(String msg) {
        super(msg);
    }
}
