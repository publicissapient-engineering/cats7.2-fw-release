#!/usr/bin/env bash

cd anoroc-core
git pull origin master

cd ../anoroc-parser
git pull origin master

cd ../anoroc-selenium-executor
git pull origin master

cd ../anoroc-reporting
git pull origin master

cd ../anoroc-cli
git pull origin master

cd ../anoroc-report-portal
git pull origin master

cd ../anoroc-ui
git pull origin master

cd ../anoroc-api
git pull origin master
