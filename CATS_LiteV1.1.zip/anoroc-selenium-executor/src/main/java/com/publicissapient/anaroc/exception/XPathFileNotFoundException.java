package com.publicissapient.anaroc.exception;

public class XPathFileNotFoundException extends RuntimeException {

    public XPathFileNotFoundException(String e) {
        super(e);
    }
}
