package com.publicissapient.anaroc.exception;

public class DebugSessionInvalidException extends RuntimeException {

    public DebugSessionInvalidException(String message) {
        super(message);
    }
}
